#import os , sys, inspect
#sys.path.insert( 0,os.path.dirname(os.path.abspath(inspect.getsourcefile(lambda:0))))
#current_dir = os.path.dirname(os.path.abspath(inspect.getsourcefile(lambda:0)))
#up_dir  = os.path.abspath(current_dir+'/../')
#sys.path.insert(1,up_dir)